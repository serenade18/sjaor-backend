from django.apps import AppConfig


class SjaorappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sjaorApp'
